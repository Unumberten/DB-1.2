package com.faskn.app.weatherapp.di

/**
 * Created by Furkan on 2019-10-26
 */

interface Injectable
